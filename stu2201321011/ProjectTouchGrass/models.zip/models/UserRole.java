package com.uni.mapsapitest.models;

public enum UserRole {
    USER,
    SPONSOR,
    ADMIN
}
